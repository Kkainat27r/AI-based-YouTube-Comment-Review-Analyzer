console.log("YouTube Comment Analyzer Loaded");

// Extract YouTube comments dynamically
function getComments() {
    const comments = [...document.querySelectorAll("#content-text")].map(c => c.innerText);
    console.log("Extracted Comments:", comments);
    chrome.runtime.sendMessage({ comments });
}

setTimeout(getComments, 5000); // Wait for YouTube to load comments


function getYouTubeVideoId() {
    let url = window.location.href;
    let videoId = null;

    if (url.includes("watch?v=")) {
        videoId = new URL(url).searchParams.get("v");
    }
    return videoId;
}

// Send video ID to background script
chrome.runtime.sendMessage({ action: "fetchComments", videoId: getYouTubeVideoId() });
