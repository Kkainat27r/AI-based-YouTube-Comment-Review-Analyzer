import React from "react";
import { auth, provider } from "./firebaseconfig";
import { signInWithPopup } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";

const LoginPage = () => {
    const navigate = useNavigate();

    const handleLogin = () => {
        signInWithPopup(auth, provider)
            .then((result) => {
                console.log("User Signed In:", result.user);
                navigate("/dashboard");
            })
            .catch((error) => console.error("Login Error", error));
    };

    return (
        <div className="login-container">
            <h2>Login to Analyze Comments</h2>
            <button className="login-btn" onClick={handleLogin}>
                Sign in with Google
            </button>
        </div>
    );
};

export default LoginPage;
