import React, { useState, useEffect } from "react";
import "./Dashboard.css";

const Dashboard = () => {
    const [comments, setComments] = useState([]);

    useEffect(() => {
        chrome.runtime.onMessage.addListener((request) => {
            if (request.comments) {
                setComments(request.comments);
            }
        });
    }, []);

    return (
        <div className="dashboard-container">
            <h1>YouTube Comment Insights</h1>
            <ul>
                {comments.map((comment, index) => (
                    <li key={index}>{comment}</li>
                ))}
            </ul>
        </div>
    );
};

export default Dashboard;
