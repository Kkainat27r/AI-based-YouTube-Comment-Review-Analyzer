import React from "react";
import { useNavigate } from "react-router-dom";
import "./WelcomePage.css";

const WelcomePage = () => {
    const navigate = useNavigate();

    return (
        <div className="welcome-container">
            <h1>Welcome to YouTube Comment Analyzer</h1>
            <p>Gain AI-powered insights on your YouTube audience.</p>
            <button className="get-started-btn" onClick={() => navigate("/login")}>
                Get Started
            </button>
        </div>
    );
};

export default WelcomePage;
