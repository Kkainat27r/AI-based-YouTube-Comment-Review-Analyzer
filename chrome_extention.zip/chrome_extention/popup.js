// popup.js
document.addEventListener("DOMContentLoaded", function () {
    // Set consistent body size
    document.body.style.width = "500px";
    document.body.style.height = "600px";
    document.body.style.overflow = "hidden";

    // Set container dimensions
    document.querySelectorAll(".popup-container").forEach(popup => {
        popup.style.width = "450px";
        popup.style.height = "auto";
    });

    const pages = document.querySelectorAll(".page");
    let videoId = '';
    
    // API response cache
    const apiCache = {
        sentiments: {},
        questions: {},
        top_comments: {},
        suggestions: {}
    };
    
    // Navigation function
    function showPage(pageId) {
        pages.forEach(page => page.style.display = "none");
        const activePage = document.getElementById(pageId);
        if (activePage) {
            activePage.style.display = "block";
            activePage.style.opacity = 0;
            setTimeout(() => activePage.style.opacity = 1, 100);
        }
    }

    // Get video ID from YouTube URL
    function getVideoId(url) {
        if (url.includes("youtube.com/watch")) {
            const urlParams = new URLSearchParams(new URL(url).search);
            return urlParams.get('v');
        } else if (url.includes("youtu.be/")) {
            return url.split("youtu.be/")[1].split("?")[0];
        }
        return '';
    }

    // Create button container HTML
    function createButtonContainer(buttons) {
        let html = '<div class="button-container">';
        buttons.forEach(btn => {
            html += `<button ${btn.id ? `id="${btn.id}"` : ''} class="${btn.class}">${btn.text}</button>`;
        });
        html += '</div>';
        return html;
    }

    // Create chart using Chart.js
    function createChart(chartId, type, data) {
        const ctx = document.getElementById(chartId);
        if (!ctx) return null;
        
        const options = {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 1.3, // Adjusted for better height utilization
            animation: { duration: 0 },
            plugins: {
                legend: { 
                    labels: { 
                        color: 'white',
                        font: { size: 14 }
                    },
                    position: 'top'
                },
                tooltip: {
                    bodyFont: { size: 14 },
                    titleFont: { size: 16 }
                }
            },
            scales: {
                x: { ticks: { color: 'white', font: { size: 12 } } },
                y: { ticks: { color: 'white', font: { size: 12 } } }
            },
            layout: { padding: 20 }
        };
        
        if (type === 'pie' || type === 'doughnut') {
            options.plugins.tooltip = { enabled: true };
            options.cutout = type === 'doughnut' ? '50%' : undefined;
            options.radius = '90%';
        }
        
        return new Chart(ctx, { type, data, options });
    }

    // Function to fetch data from API with caching
    async function fetchData(endpoint, videoId) {
        // Check cache first
        if (apiCache[endpoint][videoId]) {
            return apiCache[endpoint][videoId];
        }
        
        try {
            const response = await fetch(`https://flexible-subtly-tomcat.ngrok-free.app/${endpoint}/${videoId}`, {
                headers: { 'ngrok-skip-browser-warning': 'skip' }
            });
            
            if (!response.ok) throw new Error('Network response was not ok');
            
            const data = await response.json();
            
            // Cache the response
            apiCache[endpoint][videoId] = data;
            
            return data;
        } catch (error) {
            console.error(`Error fetching ${endpoint} data:`, error);
            return null;
        }
    }

    // Create download link for CSV
    function downloadCSV(data, filename) {
        const csvContent = "data:text/csv;charset=utf-8," + data.map(row => row.join(",")).join("\n");
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Create download link for JSON data
    function downloadJSON(data, filename) {
        const jsonContent = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
        const link = document.createElement("a");
        link.setAttribute("href", jsonContent);
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Attach event listeners to buttons
    function attachListener(elementId, event, callback) {
        const element = document.getElementById(elementId);
        if (element) element.addEventListener(event, callback);
    }

    // Show loading state
    function showLoading(container, message) {
        container.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <p>${message}</p>
            </div>
        `;
    }

    // Show error message
    function showError(container, message = "Sorry, we couldn't analyze the comments at this time.") {
        container.innerHTML = `
            <div class="error-message">
                <p>${message}</p>
                <p>Please try again later.</p>
            </div>
            ${createButtonContainer([{class: 'backBtn', text: 'Back'}])}
        `;
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
    }

    // Handle sentiments page
    async function handleSentiments() {
        showPage("sentimentPage");
        
        // Remove existing buttons
        document.querySelectorAll("#sentimentPage > button, #sentimentPage > .download-btn").forEach(btn => btn.remove());
        
        const chartContainer = document.querySelector("#sentimentPage .chart-container");
        if (!chartContainer) return;
        
        showLoading(chartContainer, "Analyzing sentiment in comments...");
        
        const data = await fetchData("sentiments", videoId);
        if (!data) {
            showError(chartContainer);
            return;
        }
        
        // Count sentiments
        const sentimentCounts = { Positive: 0, Neutral: 0, Negative: 0 };
        data.forEach(comment => {
            if (comment.sentiment in sentimentCounts) {
                sentimentCounts[comment.sentiment]++;
            }
        });
        
        // Create chart
        chartContainer.innerHTML = `
            <div class="chart-wrapper" style="height: 450px; margin-top: 40px;">
                <canvas id="sentimentChart"></canvas>
            </div>
            ${createButtonContainer([
                {class: 'backBtn', text: 'Back'},
                {id: 'downloadSentimentBtn', class: 'download-btn', text: '📥 Download'}
            ])}
        `;
        
        createChart("sentimentChart", "bar", {
            labels: ["Positive", "Neutral", "Negative"],
            datasets: [{
                label: "Sentiment Distribution",
                data: [sentimentCounts.Positive, sentimentCounts.Neutral, sentimentCounts.Negative],
                backgroundColor: ["#4CAF50", "#FFC107", "#F44336"]
            }]
        });
        
        // Add event listeners
        chartContainer.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        chartContainer.querySelector("#downloadSentimentBtn").addEventListener("click", () => {
            // Download the raw JSON data
            downloadJSON(data, `sentiment_analysis_${videoId}.json`);
        });
    }

    // Handle questions page
    async function handleQuestions() {
        showPage("questionsPage");
        
        // Remove existing buttons
        document.querySelectorAll("#questionsPage > button, #questionsPage > .download-btn").forEach(btn => btn.remove());
        
        const container = document.querySelector("#questionsPage .chart-container");
        if (!container) return;
        
        showLoading(container, "Detecting questions in comments...");
        
        const questionsData = await fetchData("questions", videoId);
        if (!questionsData || !questionsData.data || questionsData.data.length === 0) {
            showError(container, "No questions found in comments for this video.");
            return;
        }
        
        // Filter questions
        const questions = questionsData.data.filter(item => item.Classification === "question");
        if (questions.length === 0) {
            showError(container, "No questions found in comments for this video.");
            return;
        }
        
        // Show questions list
        showQuestionsList(container, questions, questionsData);
    }

    // Show questions list view
    function showQuestionsList(container, questions, questionsData) {
        let commentsHTML = `
            <div id="questionsContainer" style="max-height: 450px;">
                <ul id="questionsList">
        `;
        
        questions.forEach(question => {
            commentsHTML += `<li>${question.Clean_Comments}</li>`;
        });
        
        commentsHTML += `
                </ul>
            </div>
            ${createButtonContainer([
                {class: 'backBtn', text: 'Back'},
                {id: 'downloadQuestionsBtn', class: 'download-btn', text: '📥 Download'},
                {id: 'viewGraphBtn', class: 'view-btn', text: 'View in Graph'}
            ])}
        `;
        
        container.innerHTML = commentsHTML;
        
        // Animate questions
        animateListItems("#questionsList li");
        
        // Add event listeners
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        container.querySelector("#downloadQuestionsBtn").addEventListener("click", () => {
            // Download the raw JSON data
            downloadJSON(questionsData, `questions_data_${videoId}.json`);
        });
        container.querySelector("#viewGraphBtn").addEventListener("click", () => {
            showQuestionsGraph(container, questionsData.question_counts, questionsData.other_counts);
        });
    }

    // Show questions graph view
    function showQuestionsGraph(container, questionCount, otherCount) {
        container.innerHTML = `
            <div class="chart-wrapper" style="height: 450px; margin-top: 30px;">
                <canvas id="questionsChart"></canvas>
            </div>
            ${createButtonContainer([
                {class: 'backBtn', text: 'Back'},
                {id: 'downloadQuestionsGraphBtn', class: 'download-btn', text: '📥 Download'},
                {id: 'viewListBtn', class: 'view-btn', text: 'View Questions List'}
            ])}
        `;
        
        createChart("questionsChart", "pie", {
            labels: ["Questions", "Others"],
            datasets: [{
                label: "Question Detection",
                data: [questionCount, otherCount],
                backgroundColor: ["#B82132", "#F6DED8"]
            }]
        });
        
        // Add event listeners
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        container.querySelector("#downloadQuestionsGraphBtn").addEventListener("click", () => {
            // Download the cached JSON data
            const cachedData = apiCache["questions"][videoId];
            if (cachedData) {
                downloadJSON(cachedData, `questions_data_${videoId}.json`);
            } else {
                fetchData("questions", videoId).then(data => {
                    downloadJSON(data, `questions_data_${videoId}.json`);
                });
            }
        });
        container.querySelector("#viewListBtn").addEventListener("click", handleQuestions);
    }

    // Handle suggestions page - Updated to match Questions feature exactly
    async function handleSuggestions() {
        showPage("suggestionsPage");
        
        // Remove existing buttons
        document.querySelectorAll("#suggestionsPage > button, #suggestionsPage > .download-btn").forEach(btn => btn.remove());
        
        const container = document.querySelector("#suggestionsPage .chart-container");
        if (!container) return;
        
        showLoading(container, "Finding suggestions in comments...");
        
        const suggestionsData = await fetchData("suggestions", videoId);
        if (!suggestionsData || !suggestionsData.data || suggestionsData.data.length === 0) {
            showError(container, "No suggestions found in comments for this video.");
            return;
        }
        
        // Filter suggestions
        const suggestions = suggestionsData.data.filter(item => item.Classification === "suggestion");
        if (suggestions.length === 0) {
            showError(container, "No suggestions found in comments for this video.");
            return;
        }
        
        // Show suggestions list
        showSuggestionsList(container, suggestions, suggestionsData);
    }

    // Show suggestions list view - matches the questions list view
    function showSuggestionsList(container, suggestions, suggestionsData) {
        let commentsHTML = `
            <div id="suggestionsContainer" style="max-height: 450px;">
                <ul id="suggestionsList">
        `;
        
        suggestions.forEach(suggestion => {
            commentsHTML += `<li>${suggestion.Clean_Comments}</li>`;
        });
        
        commentsHTML += `
                </ul>
            </div>
            ${createButtonContainer([
                {class: 'backBtn', text: 'Back'},
                {id: 'downloadSuggestionsBtn', class: 'download-btn', text: '📥 Download'},
                {id: 'viewGraphBtn', class: 'view-btn', text: 'View in Graph'}
            ])}
        `;
        
        container.innerHTML = commentsHTML;
        
        // Ensure scrollbar styling is consistent
        const suggestionsContainer = document.getElementById('suggestionsContainer');
        if (suggestionsContainer) {
            // Make sure overflow is set to auto to show scrollbar when needed
            suggestionsContainer.style.overflowY = 'auto';
            
            // Force the scrollbar to be visible even if content fits
            if (suggestionsContainer.scrollHeight <= suggestionsContainer.clientHeight) {
                // Add a small padding to force scrollbar to appear
                const paddingElement = document.createElement('div');
                paddingElement.style.height = '1px';
                paddingElement.style.marginBottom = '5px';
                suggestionsContainer.appendChild(paddingElement);
            }
        }
        
        // Animate suggestions
        animateListItems("#suggestionsList li");
        
        // Add event listeners
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        container.querySelector("#downloadSuggestionsBtn").addEventListener("click", () => {
            // Download the raw JSON data
            downloadJSON(suggestionsData, `suggestions_data_${videoId}.json`);
        });
        container.querySelector("#viewGraphBtn").addEventListener("click", () => {
            showSuggestionsGraph(container, suggestionsData.suggestion_counts, suggestionsData.other_counts);
        });
    }

    // Show suggestions graph view - matches the questions graph view
    function showSuggestionsGraph(container, suggestionCount, otherCount) {
        container.innerHTML = `
            <div class="chart-wrapper" style="height: 450px; margin-top: 30px;">
                <canvas id="suggestionsChart"></canvas>
            </div>
            ${createButtonContainer([
                {class: 'backBtn', text: 'Back'},
                {id: 'downloadSuggestionsGraphBtn', class: 'download-btn', text: '📥 Download'},
                {id: 'viewListBtn', class: 'view-btn', text: 'View Suggestions'}
            ])}
        `;
        
        createChart("suggestionsChart", "pie", {
            labels: ["Suggestions", "Others"],
            datasets: [{
                label: "Suggestion Detection",
                data: [suggestionCount, otherCount],
                backgroundColor: ["#B82132", "#F6DED8"]
            }]
        });
        
        // Add event listeners
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        container.querySelector("#downloadSuggestionsGraphBtn").addEventListener("click", () => {
            // Download the cached JSON data
            const cachedData = apiCache["suggestions"][videoId];
            if (cachedData) {
                downloadJSON(cachedData, `suggestions_data_${videoId}.json`);
            } else {
                fetchData("suggestions", videoId).then(data => {
                    downloadJSON(data, `suggestions_data_${videoId}.json`);
                });
            }
        });
        container.querySelector("#viewListBtn").addEventListener("click", handleSuggestions);
    }

    // Handle top comments page
    async function handleTopComments() {
        showPage("topCommentsPage");
        
        // Remove existing buttons
        document.querySelectorAll("#topCommentsPage > button, #topCommentsPage > .download-btn").forEach(btn => btn.remove());
        
        const container = document.getElementById("topCommentsContainer");
        if (!container) return;
        
        showLoading(container, "Analyzing comments...");
        
        const commentsData = await fetchData("top_comments", videoId);
        if (!commentsData || commentsData.length === 0) {
            showError(container, "No relevant comments found for this video.");
            return;
        }
        
        // Show comments list
        let commentsHTML = '<ul id="topCommentsList" style="max-height: 430px;">';
        commentsData.forEach(comment => {
            commentsHTML += `<li>${comment.Clean_Comments}</li>`;
        });
        commentsHTML += '</ul>';
        
        commentsHTML += createButtonContainer([
            {class: 'backBtn', text: 'Back'},
            {id: 'topDownloadBtn', class: 'download-btn', text: '📥 Download'}
        ]);
        
        container.innerHTML = commentsHTML;
        
        // Animate comments
        animateListItems("#topCommentsList li");
        
        // Add event listeners
        container.querySelector(".backBtn").addEventListener("click", () => showPage("dashboardPage"));
        container.querySelector("#topDownloadBtn").addEventListener("click", () => {
            // Download the raw JSON data
            downloadJSON(commentsData, `top_comments_${videoId}.json`);
        });
    }

    // Animate list items
    function animateListItems(selector) {
        const listItems = document.querySelectorAll(selector);
        listItems.forEach((item, index) => {
            item.style.opacity = 0;
            item.style.transform = "translateY(20px) scale(0.9)";
            
            setTimeout(() => {
                item.style.transition = "opacity 0.6s ease, transform 0.6s ease";
                item.style.opacity = 1;
                item.style.transform = "translateY(0) scale(1)";
            }, index * 150);
        });
    }

    // Check if we're on YouTube
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentUrl = tabs[0].url;
        const isYouTube = currentUrl.includes("youtube.com");
        const isYouTubeVideo = currentUrl.includes("youtube.com/watch") || currentUrl.includes("youtu.be/");
        
        // Get video ID if on a video page
        if (isYouTubeVideo) {
            videoId = getVideoId(currentUrl);
        }
        
        // If not on YouTube or no video, show message
        if (!isYouTube || !isYouTubeVideo) {
            pages.forEach(page => page.style.display = "none");
            
            const messageTitle = isYouTube ? "Open a Video" : "Navigate to YouTube";
            const messageText = isYouTube 
                ? "Please open a YouTube video to analyze its comments. This extension only works on video pages."
                : "This extension works only on YouTube video pages where comments are available.";
            const buttonText = isYouTube ? "Browse Videos" : "Open YouTube";
            
            const notYouTubePage = document.createElement("div");
            notYouTubePage.id = "notYouTubePage";
            notYouTubePage.className = "page show";
            notYouTubePage.innerHTML = `
                <h2 class="title">YouTube Comment Analyzer</h2>
                <div class="not-youtube-message">
                    <h3>${messageTitle}</h3>
                    <p>${messageText}</p>
                    <button id="openYouTubeBtn" class="animated-btn">${buttonText}</button>
                </div>
            `;
            
            document.body.appendChild(notYouTubePage);
            
            // Add event listener to button
            document.getElementById("openYouTubeBtn").addEventListener("click", function() {
                const targetUrl = isYouTube ? "https://www.youtube.com/feed/trending" : "https://www.youtube.com";
                chrome.tabs.create({ url: targetUrl });
            });
            
            return;
        }
        
        // Show welcome page by default
        showPage("welcomePage");
        
        // Add event listeners for navigation
        attachListener("getStartedBtn", "click", () => showPage("dashboardPage"));
        
        document.querySelectorAll(".backBtn").forEach(btn => {
            btn.addEventListener("click", () => showPage("dashboardPage"));
        });
        
        // Add event listeners for features
        attachListener("backToWelcomeBtn", "click", () => { location.href = location.href });
        attachListener("analyzeSentimentsBtn", "click", handleSentiments);
        attachListener("detectQuestionsBtn", "click", handleQuestions);
        attachListener("findSuggestionsBtn", "click", handleSuggestions);
        attachListener("topCommentsBtn", "click", handleTopComments);
    });
});