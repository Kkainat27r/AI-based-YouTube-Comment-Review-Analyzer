chrome.runtime.onInstalled.addListener(() => {
  console.log("YouTube Comment Analyzer Extension Installed");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.comments) {
      console.log("Received comments:", message.comments);
      sendResponse({ status: "Comments received" });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "fetchComments" && message.videoId) {
      fetchYouTubeComments(message.videoId);
  }
});

async function fetchYouTubeComments(videoId) {
  let apiKey = "AIzaSyCGrovnngqvQnHsC7eb38XYgJqMQ4Rf64g";  
  let url = `https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=${videoId}&key=${apiKey}&maxResults=20`;

  try {
      let response = await fetch(url);
      let data = await response.json();

      if (data.items) {
          let comments = data.items.map(item => item.snippet.topLevelComment.snippet.textDisplay);
          chrome.storage.local.set({ comments: comments });  // Store comments in extension storage
      }
  } catch (error) {
      console.error("Error fetching comments:", error);
  }
}
